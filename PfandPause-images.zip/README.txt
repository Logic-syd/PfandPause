Game Jolt Design uploads:
Upload Game Header: gamejolt-header.png (adjust crop to keep the wordmark and bottles visible).
Game Thumbnail / Upload Thumbnail: gamejolt-thumbnail.png.
Add Media / Images: puzzle-desktop.png, recycling-desktop.png, recycling-mobile.png.
The header and thumbnail are promotional illustrations; the other PNGs are actual gameplay screenshots.
